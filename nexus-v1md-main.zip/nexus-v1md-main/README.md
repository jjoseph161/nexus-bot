<p align="center">
<strong>Nexus-1MD</strong>
</p>

<br/>

<p align="center">
<a href="https://github.com/devwhitewizard"><img title="Author" src="https://img.shields.io/badge/DevWhiteWizard-00e5ff?style=for-the-badge&logo=github&logoColor=black"></a>
<a href="https://whatsapp.com/channel/0029VbD62UY7IUYU6cftzu02"><img title="Channel" src="https://img.shields.io/badge/WA%20CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
<a href="https://chat.whatsapp.com/IVnWNxWwfT1JdG4QoZOmeL?s=cl&p=a&ilr=1"><img title="Group" src="https://img.shields.io/badge/Support%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
</p>

<p align="center">
<a href="https://github.com/devwhitewizard/nexus-v1md/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/devwhitewizard/nexus-v1md?color=00e5ff&style=flat-square&label=Stars"></a>
<a href="https://github.com/devwhitewizard/nexus-v1md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/devwhitewizard/nexus-v1md?color=00e5ff&style=flat-square&label=Forks"></a>
<a href="https://github.com/devwhitewizard/nexus-v1md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/devwhitewizard/nexus-v1md?label=Watchers&color=00e5ff&style=flat-square"></a>
<a href="https://github.com/devwhitewizard/nexus-v1md"><img title="Size" src="https://img.shields.io/github/repo-size/devwhitewizard/nexus-v1md?style=flat-square&color=00e5ff"></a>
<a href="https://github.com/devwhitewizard/nexus-v1md/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-00e5ff.svg"></a>
</p>

<p align="center">
<a href="https://github.com/devwhitewizard/nexus-v1md"><img title="Release" src="https://img.shields.io/badge/Release-v1.0.3-00e5ff?style=for-the-badge&logo=appveyor"></a>
<a href="https://github.com/devwhitewizard/nexus-v1md"><img title="Language" src="https://img.shields.io/static/v1?label=Language&message=JavaScript&style=flat-square&color=00e5ff"></a>
<img src="https://komarev.com/ghpvc/?username=devwhitewizard&label=VIEWS&style=flat-square&color=00e5ff">
</p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<br/>

<p align="center">
<strong>1. JOIN WHATSAPP CHANNEL</strong><br>
<a href="https://whatsapp.com/channel/0029VbD62UY7IUYU6cftzu02"><img src="https://img.shields.io/badge/Follow-Nexus%20MD%20Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
</p>

<p align="center">
<strong>2. JOIN WHATSAPP SUPPORT GROUP</strong><br>
<a href="https://chat.whatsapp.com/IVnWNxWwfT1JdG4QoZOmeL?s=cl&p=a&ilr=1"><img src="https://img.shields.io/badge/Join-Support%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
</p>

<p align="center">
<strong>3. STAR THE REPO ⭐</strong><br>
<a href="https://github.com/devwhitewizard/nexus-v1md"><img src="https://img.shields.io/badge/Star-Nexus%20MD-00e5ff?style=for-the-badge&logo=github&logoColor=black"></a>
</p>

<p align="center">
<strong>4. GET SESSION ID 🔑</strong><br>
<a href="https:/nexus.whitewizard.top/pair"><img src="https://img.shields.io/badge/Get%20Session%20ID-nexus--paircode-00e5ff?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZmlsbD0id2hpdGUiIGQ9Ik0xMiAxQTExIDExIDAgMCAwIDEgMTJhMTEgMTEgMCAwIDAgMTEgMTFBMTEgMTEgMCAwIDAgMjMgMTJBMTEgMTEgMCAwIDAgMTIgMU0xMiAzYTkgOSAwIDAgMSA5IDlhOSA5IDAgMCAxLTkgOWE5IDkgMCAwIDEtOS05YTkgOSAwIDAgMSA5LTltMC0yYTcgNyAwIDAgMC03IDdhNyA3IDAgMCAwIDcgN2E3IDcgMCAwIDAgNy03YTcgNyAwIDAgMC03LTd6Ii8+PC9zdmc+&logoColor=black"></a>
</p>

---

## 🚀 Deploy

<p align="center">
<strong>GET YOUR SESSION ID FIRST 🔑</strong><br>
<a href="https://nexus-paircode-1.onrender.com/">
<img src="https://img.shields.io/badge/🔑%20Get%20Session%20ID-nexus--paircode--1.onrender.com-00e5ff?style=for-the-badge" alt="Get Session ID">
</a>
</p>

<p align="center">
<strong>HEROKU</strong><br>
<a href="https://heroku.com/deploy?template=https://github.com/devwhitewizard/nexus-v1md">
<img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku" height="35">
</a>
</p>

<p align="center">
<strong>RAILWAY</strong><br>
<a href="https://railway.app/new/template?template=https://github.com/devwhitewizard/nexus-v1md">
<img src="https://railway.app/button.svg" alt="Deploy on Railway" height="35">
</a>
</p>

<p align="center">
<strong>RENDER</strong><br>
<a href="https://render.com/deploy?repo=https://github.com/devwhitewizard/nexus-v1md">
<img src="https://render.com/images/deploy-to-render-button.svg" alt="Deploy to Render" height="35">
</a>
</p>

<p align="center">
<strong>BOT HOSTING</strong><br>
<a href="https://bot-hosting.net/a/p/cmtemlp1s01dag8qcc2xypibg/deploy">
<img src="https://img.shields.io/badge/Deploy-Bot%20Hosting-7c4dff?style=for-the-badge&logo=serverfault&logoColor=white" alt="Deploy to Bot Hosting" height="35">
</a>
</p>

<p align="center">
<strong>KATABUMP</strong><br>
<a href="https://dashboard.katabump.com/dashboard#203630">
<img src="https://img.shields.io/badge/Deploy-Katabump-ff6b35?style=for-the-badge&logo=cloud&logoColor=white" alt="Deploy to Katabump" height="35">
</a>
</p>

<p align="center">
<strong>📦 DOWNLOAD BOT FILES</strong><br>
<a href="https://github.com/devwhitewizard/nexus-v1md/archive/refs/heads/main.zip">
<img src="https://img.shields.io/badge/⬇️%20Download-Bot%20Files%20(.zip)-00e5ff?style=for-the-badge&logo=github&logoColor=black" alt="Download Bot Files">
</a>
</p>

<p align="center">
<a href="https://nexus-md.vercel.app/"><img src="https://img.shields.io/badge/📖%20View%20More%20Steps-nexus--md.vercel.app-00e5ff?style=for-the-badge&logoColor=white"></a>
</p>

---

## ⚙️ Local Setup

```bash
git clone https://github.com/devwhitewizard/nexus-v1md.git
cd nexus-v1md
npm install
# Edit config.env and fill in your SUDO and SESSION_ID
npm start
```

---

## 📋 Environment Variables

| Variable | Required | Description |
|:---|:---:|:---|
| `SUDO` | ✅ | Your WhatsApp number with country code |
| `SESSION_ID` | ✅ | Session string (starts with `NEXUS~`) |
| `PREFIX` | ❌ | Command prefix (default `.`) |
| `MODE` | ❌ | `public` or `private` |
| `PAIRING_NUMBER` | ❌ | Phone number for pairing code login |
| `DATABASE_URL` | ❌ | PostgreSQL URL (falls back to SQLite) |

---

## ⚠️ Disclaimer

> This bot is not affiliated with WhatsApp or Meta. Use at your own risk.

---

<p align="center">
Made with ❤️ by <a href="https://github.com/devwhitewizard">DevWhiteWizard</a> • © 2026
</p>
